n = 15;
b = 30;
c = 35;
m = new Array(n);
summ = 0;
a = b + c;
i = 5;
if (a > a) {
a = 5;
b = 1;
} else {
b = a;
}
while (i > 5) {
m[i] = 1;
summ = summ + m[i];
}
